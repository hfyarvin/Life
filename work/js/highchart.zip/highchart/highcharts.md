### jQuery
- http://cdn.bootcss.com/jquery/2.1.4/jquery.min.js
- http://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js
- <script src="http://cdn.bootcss.com/jquery/2.1.4/jquery.min.js"></script>

### Highcharts
- <script src="http://code.highcharts.com/highcharts.js"></script>
- <script src="/highcharts/highcharts.js"></script>